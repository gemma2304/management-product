/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MenuUtama;



import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;

import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;

import java.io.FileNotFoundException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class MainFrame extends javax.swing.JFrame {
    static Statement stmt;
    static ResultSet rs;
    static PreparedStatement ps;
    static Connection conn = koneksi.koneksi.BukaKoneksi();
    
    Random rand = new Random();
    public int angkaRandom = rand.nextInt(90000000) + 10000000;
    /**
     * Creates new form MainFrame
     */
    public MainFrame() {
        initComponents();
        TampilDataPesan();
        tampilTableData();
        tampilTableDataPelanggan();
        
        comboBox();
        
//        Disable field
        txtKodeProduk.setEnabled(false);
        txtNamaProduk.setEnabled(false);
        txtHarga.setEnabled(false);
        nmr_order.setEnabled(false);
    }
    
    //    Untuk menampilkan data ke JTable.
    private void TampilDataPesan() {
        
        try {
            ps = conn.prepareStatement("Select * from pesanan;");
            rs = ps.executeQuery();
            
            DefaultTableModel tableModel = new DefaultTableModel();
//            Ini untuk menambah column header.
            tableModel.addColumn("Nomor Order");
            tableModel.addColumn("Kode Produk");
            tableModel.addColumn("Nama Produk");
            tableModel.addColumn("Total Harga");
            tableModel.addColumn("Nama Pelanggan");
            tableModel.addColumn("Status");
            
            tableModel.getDataVector().removeAllElements();
            tableModel.fireTableDataChanged();
            tableModel.setRowCount(0);
            
            while(rs.next()) {
                Object[] data = {
                    rs.getString("order_id"),
                    rs.getString("kode_produk"),
                    rs.getString("nama_produk"),
                    rs.getInt("total_harga"),
                    rs.getString("nama_pelanggan"),
                    rs.getString("status")
                };
                 tableModel.addRow(data);
                 table_pesanan.setModel(tableModel);
                 tbldata_pesan.setModel(tableModel);
            }
            
           
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tidak dapat menampilkan data!","Tidak bisa terhubung",JOptionPane.WARNING_MESSAGE);
        }
    }
   
//    Ini untuk menampilkan data produk ke table Order
    private void tampilTableData(){
        try {
            ps = conn.prepareStatement("Select * from produk;");
            rs = ps.executeQuery();
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("Kode Produk");
            model.addColumn("Nama Produk");
            model.addColumn("Harga");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            model.setRowCount(0);
            
            while(rs.next()){
                Object[] data = {
                    rs.getString("kode_produk"),
                    rs.getString("nama_produk"),
                    rs.getString("harga")
                };
                model.addRow(data);
                tabel_data.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tidak dapat menampilkan data!","Tidak bisa terhubung",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void tampilTableDataPelanggan(){
        try {
            ps = conn.prepareStatement("Select * from pelanggan;");
            rs = ps.executeQuery();
            DefaultTableModel model = new DefaultTableModel();
            
            model.addColumn("Id");
            model.addColumn("Nama");
            model.addColumn("Alamat");
            model.addColumn("Nomor HP");
            model.addColumn("Email");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            model.setRowCount(0);
            
            while(rs.next()){
                Object[] data = {
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("alamat"),
                    rs.getString("no_hp"),
                    rs.getString("email")
                };
                model.addRow(data);
                tblPelanggan.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tidak dapat menampilkan data!","Tidak bisa terhubung",JOptionPane.WARNING_MESSAGE);
        }
    }
    
//    Menambah data ke comboBox
    private void comboBox(){
        try {
            ps = conn.prepareStatement("SELECT * FROM pelanggan;");
            rs = ps.executeQuery();
            while(rs.next()){
                String name = rs.getString("nama");
                isiComboBox.addItem(name);
            }   
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    // Metode untuk membersihkan kolom
    private void clearFields() {
        txtNama.setText("");
        txtAlamat.setText("");
        txtNomorHp.setText("");
        txtEmail.setText("");
        txtKodeProduk.setText("");
        txtHarga.setText("");
        txtNamaProduk.setText("");
        txtJumlah.setText("");
        txtnama.getText(); 
        txtharga.getText();
        nmr_order.getText();
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        homeBtn = new javax.swing.JButton();
        orderBtn = new javax.swing.JButton();
        userBtn = new javax.swing.JButton();
        listBtn = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        halaman_utama = new javax.swing.JPanel();
        download_laporan_btn = new javax.swing.JButton();
        input_field = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_pesanan = new javax.swing.JTable();
        halaman_user = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        txtAlamat = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNomorHp = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblPelanggan = new javax.swing.JTable();
        addPelangganBtn = new javax.swing.JButton();
        editPelangganBtn = new javax.swing.JButton();
        delPelangganBtn = new javax.swing.JButton();
        halaman_order = new javax.swing.JPanel();
        txtKodeProduk = new javax.swing.JTextField();
        kode_produk = new javax.swing.JLabel();
        txtJumlah = new javax.swing.JTextField();
        jumlah = new javax.swing.JLabel();
        harga = new javax.swing.JLabel();
        txtHarga = new javax.swing.JTextField();
        txtNamaProduk = new javax.swing.JTextField();
        nama_produk = new javax.swing.JLabel();
        isiComboBox = new javax.swing.JComboBox<>();
        pelanggan = new javax.swing.JLabel();
        btnSimpan = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel_data = new javax.swing.JTable();
        list_pesanan = new javax.swing.JPanel();
        cmbstatus = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtharga = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        nmr_order = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbldata_pesan = new javax.swing.JTable();
        btnedit = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        homeBtn.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        homeBtn.setText("Home");
        homeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeBtnActionPerformed(evt);
            }
        });

        orderBtn.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        orderBtn.setText("Pesan");
        orderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderBtnActionPerformed(evt);
            }
        });

        userBtn.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        userBtn.setText("Pelanggan");
        userBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userBtnActionPerformed(evt);
            }
        });

        listBtn.setFont(new java.awt.Font("Poppins", 1, 14)); // NOI18N
        listBtn.setText("List");
        listBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(listBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(userBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(homeBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(orderBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(homeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(userBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(orderBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(listBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 561));

        download_laporan_btn.setBackground(new java.awt.Color(0, 204, 51));
        download_laporan_btn.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        download_laporan_btn.setForeground(new java.awt.Color(255, 255, 255));
        download_laporan_btn.setText("Laporan");
        download_laporan_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                download_laporan_btnActionPerformed(evt);
            }
        });

        input_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                input_fieldActionPerformed(evt);
            }
        });
        input_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                input_fieldKeyReleased(evt);
            }
        });

        table_pesanan.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        table_pesanan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Produk", "Nama Produk", "Total Harga", "Nama Pelanggan", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table_pesanan.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(table_pesanan);

        javax.swing.GroupLayout halaman_utamaLayout = new javax.swing.GroupLayout(halaman_utama);
        halaman_utama.setLayout(halaman_utamaLayout);
        halaman_utamaLayout.setHorizontalGroup(
            halaman_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_utamaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(halaman_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(halaman_utamaLayout.createSequentialGroup()
                        .addComponent(download_laporan_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(506, 506, 506)
                        .addComponent(input_field, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 796, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        halaman_utamaLayout.setVerticalGroup(
            halaman_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_utamaLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(halaman_utamaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(download_laporan_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(input_field, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        jTabbedPane1.addTab("tab1", halaman_utama);

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel1.setText("Nama");

        jLabel2.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel2.setText("Alamat");

        jLabel5.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel5.setText("Email");

        jLabel3.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel3.setText("Nomor HP");

        tblPelanggan.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        tblPelanggan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nama", "Alamat", "Nomor HP", "Email"
            }
        ));
        tblPelanggan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPelangganMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblPelanggan);

        addPelangganBtn.setBackground(new java.awt.Color(0, 153, 51));
        addPelangganBtn.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        addPelangganBtn.setForeground(new java.awt.Color(255, 255, 255));
        addPelangganBtn.setText("Tambah");
        addPelangganBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPelangganBtnActionPerformed(evt);
            }
        });

        editPelangganBtn.setBackground(new java.awt.Color(255, 204, 0));
        editPelangganBtn.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        editPelangganBtn.setForeground(new java.awt.Color(51, 51, 51));
        editPelangganBtn.setText("Edit");
        editPelangganBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editPelangganBtnActionPerformed(evt);
            }
        });

        delPelangganBtn.setBackground(new java.awt.Color(204, 0, 0));
        delPelangganBtn.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        delPelangganBtn.setForeground(new java.awt.Color(255, 255, 255));
        delPelangganBtn.setText("Hapus");
        delPelangganBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delPelangganBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout halaman_userLayout = new javax.swing.GroupLayout(halaman_user);
        halaman_user.setLayout(halaman_userLayout);
        halaman_userLayout.setHorizontalGroup(
            halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_userLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(halaman_userLayout.createSequentialGroup()
                        .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(halaman_userLayout.createSequentialGroup()
                                .addComponent(addPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(editPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(halaman_userLayout.createSequentialGroup()
                                .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                    .addComponent(txtNama))
                                .addGap(78, 78, 78)))
                        .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(halaman_userLayout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(delPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(halaman_userLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNomorHp, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(93, Short.MAX_VALUE))
        );
        halaman_userLayout.setVerticalGroup(
            halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_userLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(halaman_userLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNomorHp, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(halaman_userLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtAlamat)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(addPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(halaman_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(delPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(editPelangganBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(69, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", halaman_user);

        txtKodeProduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKodeProdukActionPerformed(evt);
            }
        });

        kode_produk.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        kode_produk.setText("Kode Produk");

        jumlah.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jumlah.setText("Jumlah");

        harga.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        harga.setText("Harga");

        txtNamaProduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaProdukActionPerformed(evt);
            }
        });

        nama_produk.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        nama_produk.setText("Nama Produk");

        isiComboBox.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N

        pelanggan.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        pelanggan.setText("Pelanggan");

        btnSimpan.setBackground(new java.awt.Color(153, 0, 153));
        btnSimpan.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        btnSimpan.setForeground(new java.awt.Color(255, 255, 255));
        btnSimpan.setText("Pesan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        tabel_data.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        tabel_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Kode Produk", "Nama Produk", "Harga"
            }
        ));
        tabel_data.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_dataMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel_data);

        javax.swing.GroupLayout halaman_orderLayout = new javax.swing.GroupLayout(halaman_order);
        halaman_order.setLayout(halaman_orderLayout);
        halaman_orderLayout.setHorizontalGroup(
            halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_orderLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(halaman_orderLayout.createSequentialGroup()
                        .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nama_produk)
                            .addComponent(kode_produk)
                            .addComponent(txtNamaProduk, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                            .addComponent(txtKodeProduk))
                        .addGap(39, 39, 39)
                        .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(halaman_orderLayout.createSequentialGroup()
                                .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtJumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(harga, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30)
                                .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(isiComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pelanggan)
                                    .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jumlah))))
                .addContainerGap(138, Short.MAX_VALUE))
        );
        halaman_orderLayout.setVerticalGroup(
            halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(halaman_orderLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(halaman_orderLayout.createSequentialGroup()
                        .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(halaman_orderLayout.createSequentialGroup()
                                .addComponent(kode_produk)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtKodeProduk))
                            .addGroup(halaman_orderLayout.createSequentialGroup()
                                .addComponent(harga)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(halaman_orderLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(nama_produk))
                            .addGroup(halaman_orderLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jumlah)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(halaman_orderLayout.createSequentialGroup()
                        .addComponent(pelanggan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isiComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)))
                .addGroup(halaman_orderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNamaProduk, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtJumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab3", halaman_order);

        cmbstatus.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        cmbstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Diproses", "Dikirim", "Diterima" }));
        cmbstatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbstatusActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel4.setText("Status");

        txtharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txthargaActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel6.setText("Total Harga");

        jLabel7.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel7.setText("Nama Pelanggan");

        nmr_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nmr_orderActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel8.setText("No Order");

        tbldata_pesan.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        tbldata_pesan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Produk", "Nama Produk", "Total Harga", "Nama Pelanggan", "Status Pesanan"
            }
        ));
        tbldata_pesan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbldata_pesanMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbldata_pesan);

        btnedit.setBackground(new java.awt.Color(255, 204, 0));
        btnedit.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        btnedit.setForeground(new java.awt.Color(51, 51, 51));
        btnedit.setText("Edit");
        btnedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditActionPerformed(evt);
            }
        });

        btnhapus.setBackground(new java.awt.Color(204, 0, 0));
        btnhapus.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        btnhapus.setForeground(new java.awt.Color(255, 255, 255));
        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout list_pesananLayout = new javax.swing.GroupLayout(list_pesanan);
        list_pesanan.setLayout(list_pesananLayout);
        list_pesananLayout.setHorizontalGroup(
            list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(list_pesananLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(list_pesananLayout.createSequentialGroup()
                        .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(nmr_order, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE)
                            .addComponent(txtnama))
                        .addGap(66, 66, 66)
                        .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtharga, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61)
                        .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnhapus, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                            .addComponent(btnedit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(129, Short.MAX_VALUE))
        );
        list_pesananLayout.setVerticalGroup(
            list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(list_pesananLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel6))
                .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(list_pesananLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nmr_order, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(txtharga)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, list_pesananLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(btnedit, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(list_pesananLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(list_pesananLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(list_pesananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnhapus, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
        );

        jTabbedPane1.addTab("tab4", list_pesanan);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(142, -29, -1, 590));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void homeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeBtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_homeBtnActionPerformed

    private void userBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userBtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_userBtnActionPerformed

    private void orderBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderBtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_orderBtnActionPerformed

    private void listBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listBtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_listBtnActionPerformed

    private void download_laporan_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_download_laporan_btnActionPerformed
        // TODO add your handling code here:
        // TODO code application logic here
        String path="target/laporan.pdf";
        PdfWriter pdfWriter;
        try {
            pdfWriter = new PdfWriter(path);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);
            pdfDocument.setDefaultPageSize(PageSize.A4);

            Document document = new Document(pdfDocument);

            //        Ini untuk GET data dari DB
            ps = conn.prepareStatement("Select * from pesanan;");
            rs = ps.executeQuery();

            //        Code dibawah digunakan untuk pembuatan table
            float threecol = 190f;
            float twocol = 285f;
            float twocol150 = twocol+150f;

            float twocolumnWidth[] = {twocol150, twocol};
            float fourcolumnWIdth[] = {threecol, threecol, threecol, threecol, threecol};
            float fullWidth[] = {threecol*3};
            Paragraph spasi = new Paragraph("\n"); // ini dipakai untuk jarak atau spasi.

            Table table = new Table(twocolumnWidth);
            table.addCell(new Cell().add("Laporan Pemesanan").setFontSize(20f).setBorder(Border.NO_BORDER).setBold());

            Border garis = new SolidBorder(Color.DARK_GRAY, 2f/2f);
            Table pemisah = new Table(fullWidth);
            pemisah.setBorder(garis);

            Table HeaderTableLaporan = new Table(fourcolumnWIdth);
            HeaderTableLaporan.setBackgroundColor(Color.BLACK, 0.7f);

            HeaderTableLaporan.addCell(paragraphLeft("Kode Produk", true));
            HeaderTableLaporan.addCell(paragraphLeft("Nama Produk", true));
            HeaderTableLaporan.addCell(paragraphLeft("Pelanggan", true));
            HeaderTableLaporan.addCell(paragraphLeft("Total", true));
            HeaderTableLaporan.addCell(paragraphLeft("Status Order", true));

            List<Laporan> daftar_laporan = new ArrayList<>();
            while(rs.next()) {
                //            Ambil data dari table
                String kd_produk = rs.getString("kode_produk");
                String nama_produk = rs.getString("nama_produk");
                String pelanggan = rs.getString("nama_pelanggan");
                String status  = rs.getString("status");
                int total_harga = rs.getInt("total_harga");

                daftar_laporan.add(new Laporan(kd_produk, nama_produk, pelanggan, total_harga, status));
            }

            Table tableLaporan = new Table(fourcolumnWIdth);

            float totalPendapatan = 0f;
            for(Laporan laporan: daftar_laporan) {
                float total = laporan.getTotal_pesanan() *2;
                totalPendapatan+=total;

                //            Code dibawah untuk menambahkan data ke tablenya, kalau mau atur posisinya bisa ubah marginnya.
                tableLaporan.addCell(new Cell().add(laporan.getKd_produk()).setBorder(Border.NO_BORDER).setMarginLeft(10f));
                tableLaporan.addCell(new Cell().add(laporan.getNm_produk()).setMarginLeft(10f).setBorder(Border.NO_BORDER));
                tableLaporan.addCell(new Cell().add(laporan.getPelanggan()).setBorder(Border.NO_BORDER).setMarginLeft(15f));
                tableLaporan.addCell(new Cell().add(String.valueOf(laporan.getTotal_pesanan())).setBorder(Border.NO_BORDER).setMarginLeft(20f));
                tableLaporan.addCell(new Cell().add(laporan.getStatus()).setBorder(Border.NO_BORDER).setMarginLeft(20f));
            }

            document.add(table);
            document.add(pemisah);
            document.add(spasi);
            document.add(HeaderTableLaporan);
            document.add(tableLaporan.setMarginBottom(20f));
            //        document.add(new Paragraph("Total: Rp. 20.0000.000").setFontSize(15f));

            rs.close();
            document.close();

            JOptionPane.showMessageDialog(this, "Laporan Berhasil Dibuat!");

        } catch (FileNotFoundException | SQLException ex) {
            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_download_laporan_btnActionPerformed

    private void input_fieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_input_fieldKeyReleased
        // TODO add your handling code here:
        DefaultTableModel tableModel = (DefaultTableModel) table_pesanan.getModel();
        TableRowSorter<DefaultTableModel> obj = new TableRowSorter<>(tableModel);
        table_pesanan.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(input_field.getText()));
    }//GEN-LAST:event_input_fieldKeyReleased

    private void input_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_input_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_input_fieldActionPerformed

    private void txtKodeProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKodeProdukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtKodeProdukActionPerformed

    private void txtNamaProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaProdukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaProdukActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
        try {
            
            if(txtKodeProduk.getText().equals("") || txtHarga.getText().equals("") ||
                txtNamaProduk.getText().equals("") || txtJumlah.getText().equals("") ){
                JOptionPane.showMessageDialog(null, "data tidak boleh kosong","validasi",JOptionPane.WARNING_MESSAGE);
                return;
            } else {
                int totalHarga = Integer.valueOf(txtHarga.getText()) * Integer.valueOf(txtJumlah.getText());
                String nomorOrder = "ORD" + angkaRandom;
                
                String tambah_pesanan = "INSERT INTO pesanan (order_id, kode_produk, nama_produk, total_harga, nama_pelanggan, status) VALUES(?, ?, ?, ?, ?, 'Diproses')";
                ps = conn.prepareStatement(tambah_pesanan);
                ps.setString(1, nomorOrder);
                ps.setString(2, txtKodeProduk.getText() );
                ps.setString(3, txtNamaProduk.getText());
                ps.setInt(4, totalHarga);
                ps.setString(5, isiComboBox.getSelectedItem().toString());
                ps.executeUpdate();
                
                TampilDataPesan();
                clearFields();
                JOptionPane.showMessageDialog(null, "Orderan Berhasil Dibuat!");
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void tabel_dataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_dataMouseClicked
        // TODO add your handling code here:
        txtKodeProduk.setText(tabel_data.getValueAt(tabel_data.getSelectedRow(),0).toString());
        txtNamaProduk.setText(tabel_data.getValueAt(tabel_data.getSelectedRow(),1).toString());
        txtHarga.setText(tabel_data.getValueAt(tabel_data.getSelectedRow(),2).toString());
    }//GEN-LAST:event_tabel_dataMouseClicked

    private void tblPelangganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPelangganMouseClicked
        // TODO add your handling code here:
        int id = Integer.parseInt(tblPelanggan.getValueAt(tblPelanggan.getSelectedRow(), 0).toString());
        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/javadb", "root", "");
//            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
//            ResultSet res = st.executeQuery("SELECT * FROM pelanggan WHERE id = " + id);
            
            ps = conn.prepareStatement("SELECT * FROM pelanggan WHERE id = " + id);
            rs = ps.executeQuery();

            while (rs.next()) {
                txtNama.setText(rs.getString("nama").toString());
                txtAlamat.setText(rs.getString("alamat"));
                txtNomorHp.setText(rs.getString("no_hp"));
                txtEmail.setText(rs.getString("email"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_tblPelangganMouseClicked

    private void editPelangganBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editPelangganBtnActionPerformed
        // TODO add your handling code here:
        try {
            if (tblPelanggan.getSelectedRow() == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris yang ingin diedit!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int id = Integer.parseInt(tblPelanggan.getValueAt(tblPelanggan.getSelectedRow(), 0).toString());

            if (txtNama.getText().isEmpty() || txtAlamat.getText().isEmpty() || txtNomorHp.getText().isEmpty() || txtEmail.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua data harus diisi!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            boolean data = st.execute("UPDATE pelanggan SET nama = '"+ txtNama.getText() +"', alamat = '"+ txtAlamat.getText() +"', no_hp = '"+ txtNomorHp.getText() +"', email = '"+ txtEmail.getText() +"' WHERE id = " + id);
            if ( !data ) {
                tampilTableDataPelanggan();
                clearFields();
                JOptionPane.showMessageDialog(this, "Berhasil update data!", "info", JOptionPane.INFORMATION_MESSAGE);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_editPelangganBtnActionPerformed

    private void delPelangganBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delPelangganBtnActionPerformed
        // TODO add your handling code here:
        try {
            if (tblPelanggan.getSelectedRow() == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris yang akan dihapus!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            } else {
                int id = Integer.parseInt(tblPelanggan.getValueAt(tblPelanggan.getSelectedRow(), 0).toString());
            
                Statement st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

                int r = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?");
                if (r == 0) {
                    if(!st.execute("DELETE FROM pelanggan WHERE id = " + id)){
                        tampilTableDataPelanggan();
                        clearFields();
                    }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_delPelangganBtnActionPerformed

    private void addPelangganBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPelangganBtnActionPerformed
        // TODO add your handling code here:
        try {
            
            if(txtNama.getText().equals("") || txtAlamat.getText().equals("") ||
                txtNomorHp.getText().equals("") || txtEmail.getText().equals("") ){
                JOptionPane.showMessageDialog(this, "Data masih ada yang kosong!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            } else {
                String user = "INSERT INTO pelanggan (nama, alamat, no_hp, email) VALUES(?, ?, ?, ?)";
                ps = conn.prepareStatement(user);
                ps.setString(1, txtNama.getText() );
                ps.setString(2, txtAlamat.getText());
                ps.setString(3, txtNomorHp.getText());
                ps.setString(4, txtEmail.getText());
                ps.executeUpdate();
                
                tampilTableDataPelanggan();
                clearFields();
                JOptionPane.showMessageDialog(null, "User Berhasil ditambahkan!");
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        
    }//GEN-LAST:event_addPelangganBtnActionPerformed

    private void txthargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txthargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txthargaActionPerformed

    private void nmr_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nmr_orderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nmr_orderActionPerformed

    private void cmbstatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbstatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbstatusActionPerformed

    private void tbldata_pesanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbldata_pesanMouseClicked
        // TODO add your handling code here:
        nmr_order.setText(tbldata_pesan.getValueAt(tbldata_pesan.getSelectedRow(), 0).toString());
        txtharga.setText(tbldata_pesan.getValueAt(tbldata_pesan.getSelectedRow(), 3).toString());
        txtnama.setText(tbldata_pesan.getValueAt(tbldata_pesan.getSelectedRow(), 4).toString());
        
    }//GEN-LAST:event_tbldata_pesanMouseClicked

    private void btneditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditActionPerformed
        // TODO add your handling code here:
        try {
                if (txtnama.getText().equals("") || txtharga.getText().equals("") || nmr_order.getText().equals("")  ) {
                    JOptionPane.showMessageDialog(null, "data tidak boleh kosong","validasi",JOptionPane.WARNING_MESSAGE);
                } else {
                    String order_id = nmr_order.getText();
                    String nama = txtnama.getText();
                    String harga = txtharga.getText();
                    String status = cmbstatus.getSelectedItem().toString();

                    String sql = "UPDATE pesanan SET nama_produk=?, total_harga=?, nama_pelanggan=?, status=? WHERE order_id=?";
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, nama);
                    ps.setString(2, harga);
                    ps.setString(3, nama);
                    ps.setString(4, status);
                    ps.setString(5, order_id);

                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data berhasil diupdate!");
                    
                    TampilDataPesan();
//                    TampilDataPesan2();
                    clearFields();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_btneditActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        // TODO add your handling code here:
        if (txtnama.getText().equals("") || txtharga.getText().equals("") || nmr_order.getText().equals("")  ) {
            JOptionPane.showMessageDialog(this, "Silahkan pilih data yang mau dihapus!");
        } else {
            int jawab = JOptionPane.showConfirmDialog(null, "Data ini akan dihapus, lanjutkan ?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (jawab == 0) {
                try {
                    String sql = "DELETE FROM pesanan WHERE order_id = ?";
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, nmr_order.getText());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
                    
                    TampilDataPesan();
//                    TampilDataPesan2();
                    clearFields();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }
            }
        }
    }//GEN-LAST:event_btnhapusActionPerformed
    
    static Cell paragraphLeft(String textValue, Boolean isBold) {
        Cell cellBaru = new Cell().add(textValue).setFontSize(10f).setFontColor(Color.WHITE).setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.LEFT);
        return isBold ? cellBaru.setBold() : cellBaru;  // Ini operator, kalau isBold = true variabelnya akan ditambahkan setBold()
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addPelangganBtn;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnedit;
    private javax.swing.JButton btnhapus;
    private javax.swing.JComboBox<String> cmbstatus;
    private javax.swing.JButton delPelangganBtn;
    private javax.swing.JButton download_laporan_btn;
    private javax.swing.JButton editPelangganBtn;
    private javax.swing.JPanel halaman_order;
    private javax.swing.JPanel halaman_user;
    private javax.swing.JPanel halaman_utama;
    private javax.swing.JLabel harga;
    private javax.swing.JButton homeBtn;
    private javax.swing.JTextField input_field;
    private javax.swing.JComboBox<String> isiComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel jumlah;
    private javax.swing.JLabel kode_produk;
    private javax.swing.JButton listBtn;
    private javax.swing.JPanel list_pesanan;
    private javax.swing.JLabel nama_produk;
    private javax.swing.JTextField nmr_order;
    private javax.swing.JButton orderBtn;
    private javax.swing.JLabel pelanggan;
    private javax.swing.JTable tabel_data;
    private javax.swing.JTable table_pesanan;
    private javax.swing.JTable tblPelanggan;
    private javax.swing.JTable tbldata_pesan;
    private javax.swing.JTextField txtAlamat;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtJumlah;
    private javax.swing.JTextField txtKodeProduk;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNamaProduk;
    private javax.swing.JTextField txtNomorHp;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtnama;
    private javax.swing.JButton userBtn;
    // End of variables declaration//GEN-END:variables
}


// Class tambahan
class Laporan {
    private String kd_produk;
    private String nm_produk;
    private String pelanggan;
    private int total_pesanan;
    private String status;

    public Laporan(String kd_produk, String nm_produk, String pelanggan, int total_pesanan, String status) {
        this.kd_produk = kd_produk;
        this.nm_produk = nm_produk;
        this.pelanggan = pelanggan;
        this.total_pesanan = total_pesanan;
        this.status = status;
    }
    
    
    public String getKd_produk() {
        return kd_produk;
    }

    public void setKd_produk(String kd_produk) {
        this.kd_produk = kd_produk;
    }

    public String getNm_produk() {
        return nm_produk;
    }

    public void setNm_produk(String nm_produk) {
        this.nm_produk = nm_produk;
    }

    public String getPelanggan() {
        return pelanggan;
    }

    public void setPelanggan(String pelanggan) {
        this.pelanggan = pelanggan;
    }

    public int getTotal_pesanan() {
        return total_pesanan;
    }

    public void setTotal_pesanan(int total_pesanan) {
        this.total_pesanan = total_pesanan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}